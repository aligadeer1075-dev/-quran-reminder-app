package com.example.quranreminder;

import android.app.*;
import android.content.*;
import android.os.Build;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;

public class ReminderReceiver extends BroadcastReceiver {
    static final String PREF = "quran_prefs";
    static final String CHANNEL = "quran_verses";

    public static PendingIntent pendingIntent(Context c) {
        Intent i = new Intent(c, ReminderReceiver.class);
        return PendingIntent.getBroadcast(c, 77, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    public static void schedule(Context c, long delay) {
        AlarmManager am = (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        long when = System.currentTimeMillis() + Math.max(1000, delay);
        PendingIntent pi = pendingIntent(c);
        if (Build.VERSION.SDK_INT >= 23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, when, pi);
        else am.set(AlarmManager.RTC_WAKEUP, when, pi);
    }

    @Override public void onReceive(Context context, Intent intent) {
        Context app = context.getApplicationContext();
        android.content.SharedPreferences p = app.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!p.getBoolean("enabled", false)) return;
        PendingResult pending = goAsync();
        new Thread(() -> {
            try {
                int n = p.getInt("reminder_ayah", p.getInt("ayah", 1));
                String start = p.getString("start", "11:00"), end = p.getString("end", "22:00");
                int interval = Math.max(5, p.getInt("interval", 15));
                if (!insideWindow(start, end)) {
                    schedule(app, nextWindowDelay(start));
                    return;
                }
                URL url = new URL("https://api.alquran.cloud/v1/ayah/" + n + "/quran-uthmani");
                HttpURLConnection c = (HttpURLConnection)url.openConnection(); c.setConnectTimeout(10000); c.setReadTimeout(10000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder(); String line; while((line=r.readLine())!=null) sb.append(line); c.disconnect();
                JSONObject data = new JSONObject(sb.toString()).getJSONObject("data");
                String text = data.getString("text");
                String surah = data.getJSONObject("surah").getString("name");
                int ayahInSurah = data.getInt("numberInSurah");
                int next = n >= 6236 ? 1 : n + 1;
                p.edit().putInt("reminder_ayah", next).apply();

                Intent open = new Intent(app, MainActivity.class);
                open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                open.putExtra("ayah", n);
                PendingIntent tap = PendingIntent.getActivity(app, 1000+n, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(app, CHANNEL) : new Notification.Builder(app);
                b.setSmallIcon(android.R.drawable.ic_dialog_info)
                    .setContentTitle("القرآن الكريم — " + surah + "، الآية " + ayahInSurah)
                    .setContentText(text)
                    .setStyle(new Notification.BigTextStyle().bigText(text + "\n" + surah + " — الآية " + ayahInSurah))
                    .setContentIntent(tap).setAutoCancel(true).setPriority(Notification.PRIORITY_HIGH);
                if (Build.VERSION.SDK_INT < 33 || app.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    ((NotificationManager)app.getSystemService(Context.NOTIFICATION_SERVICE)).notify(501, b.build());
                }
                schedule(app, interval * 60L * 1000L);
            } catch(Exception e) {
                schedule(app, 15 * 60L * 1000L);
            } finally { pending.finish(); }
        }).start();
    }

    static boolean insideWindow(String s, String e) {
        try {
            int a = toMinutes(s), b = toMinutes(e);
            Calendar now = Calendar.getInstance(); int cur = now.get(Calendar.HOUR_OF_DAY)*60 + now.get(Calendar.MINUTE);
            return a <= b ? cur >= a && cur <= b : cur >= a || cur <= b;
        } catch(Exception ex) { return true; }
    }
    static long nextWindowDelay(String s) {
        try {
            int target = toMinutes(s); Calendar now = Calendar.getInstance();
            int cur = now.get(Calendar.HOUR_OF_DAY)*60 + now.get(Calendar.MINUTE);
            int delta = target - cur; if (delta <= 0) delta += 24*60;
            return delta * 60L * 1000L;
        } catch(Exception ex) { return 15*60*1000L; }
    }
    static int toMinutes(String s) {
        String[] a=s.split(":"); return Integer.parseInt(a[0])*60 + Integer.parseInt(a[1]);
    }
}
