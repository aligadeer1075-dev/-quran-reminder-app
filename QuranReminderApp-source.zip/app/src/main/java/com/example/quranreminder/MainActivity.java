package com.example.quranreminder;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import org.json.JSONObject;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Calendar;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    static final String PREF = "quran_prefs";
    static final String CHANNEL = "quran_verses";
    TextView verseText, refText, statusText;
    EditText startTime, endTime, intervalMinutes;
    Spinner themeSpinner;
    int ayahNumber = 1;
    JSONObject currentAyah;
    MediaPlayer player;
    ExecutorService executor = Executors.newSingleThreadExecutor();
    int bg = Color.WHITE, fg = Color.BLACK;

    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.hasExtra("ayah") && verseText != null) loadAyah(intent.getIntExtra("ayah", 1));
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        createChannel();
        getPreferences(MODE_PRIVATE);
        ayahNumber = getSharedPreferences(PREF, MODE_PRIVATE).getInt("ayah", 1);
        if (getIntent() != null && getIntent().hasExtra("ayah")) ayahNumber = getIntent().getIntExtra("ayah", ayahNumber);
        buildUi();
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100);
        loadAyah(ayahNumber);
    }

    void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(22, 20, 22, 24);
        root.setGravity(Gravity.CENTER_HORIZONTAL);
        scroll.addView(root);
        setContentView(scroll);

        TextView title = new TextView(this);
        title.setText("تذكير القرآن الكريم");
        title.setTextSize(25); title.setGravity(Gravity.CENTER); title.setTextColor(fg);
        root.addView(title, matchWrap());
        verseText = new TextView(this);
        verseText.setText("جارٍ تحميل الآية...");
        verseText.setTextSize(28); verseText.setGravity(Gravity.CENTER); verseText.setPadding(8, 36, 8, 28);
        root.addView(verseText, matchWrap());
        refText = new TextView(this); refText.setTextSize(18); refText.setGravity(Gravity.CENTER);
        root.addView(refText, matchWrap());

        LinearLayout nav = new LinearLayout(this); nav.setGravity(Gravity.CENTER);
        Button prev = new Button(this); prev.setText("الآية السابقة");
        Button next = new Button(this); next.setText("الآية التالية");
        Button listen = new Button(this); listen.setText("استماع");
        nav.addView(prev); nav.addView(listen); nav.addView(next); root.addView(nav, matchWrap());
        prev.setOnClickListener(v -> loadAyah(Math.max(1, ayahNumber - 1)));
        next.setOnClickListener(v -> loadAyah(Math.min(6236, ayahNumber + 1)));
        listen.setOnClickListener(v -> playAyah());

        addHeading(root, "إعدادات التذكير");
        intervalMinutes = new EditText(this); intervalMinutes.setSingleLine(true);
        intervalMinutes.setInputType(2); intervalMinutes.setHint("الفاصل بالدقائق (مثلاً 15)");
        intervalMinutes.setText(String.valueOf(getSharedPreferences(PREF, MODE_PRIVATE).getInt("interval", 15)));
        root.addView(intervalMinutes, matchWrap());

        LinearLayout times = new LinearLayout(this);
        startTime = new EditText(this); startTime.setSingleLine(true); startTime.setHint("البداية HH:MM");
        startTime.setText(getSharedPreferences(PREF, MODE_PRIVATE).getString("start", "11:00"));
        endTime = new EditText(this); endTime.setSingleLine(true); endTime.setHint("النهاية HH:MM");
        endTime.setText(getSharedPreferences(PREF, MODE_PRIVATE).getString("end", "22:00"));
        times.addView(startTime, new LinearLayout.LayoutParams(0, -2, 1));
        times.addView(endTime, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(times, matchWrap());

        Button enable = new Button(this); enable.setText("حفظ وتشغيل التذكير");
        root.addView(enable, matchWrap());
        Button disable = new Button(this); disable.setText("إيقاف التذكير");
        root.addView(disable, matchWrap());

        addHeading(root, "ألوان التطبيق");
        themeSpinner = new Spinner(this);
        String[] themes = {"أبيض وأسود", "داكن", "أخضر هادئ", "رملي"};
        themeSpinner.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, themes));
        root.addView(themeSpinner, matchWrap());
        themeSpinner.setSelection(getSharedPreferences(PREF, MODE_PRIVATE).getInt("theme", 0));
        themeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) { applyTheme(pos); }
        });
        statusText = new TextView(this); statusText.setTextSize(14); statusText.setPadding(0, 12, 0, 0);
        root.addView(statusText, matchWrap());

        enable.setOnClickListener(v -> {
            try {
                int mins = Integer.parseInt(intervalMinutes.getText().toString().trim());
                if (mins < 5) { toast("أقل فاصل مسموح به هو 5 دقائق."); return; }
                String s = startTime.getText().toString().trim(), e = endTime.getText().toString().trim();
                if (!validTime(s) || !validTime(e)) { toast("اكتبي الوقت بصيغة 11:00 أو 22:00."); return; }
                getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("interval", mins).putString("start", s).putString("end", e).putBoolean("enabled", true).putInt("reminder_ayah", getSharedPreferences(PREF, MODE_PRIVATE).getInt("reminder_ayah", ayahNumber)).apply();
                ReminderReceiver.schedule(this, 1000);
                statusText.setText("تم حفظ الإعدادات. يعتمد وصول الإشعارات على اتصال الإنترنت وإعدادات الهاتف.");
                toast("تم تشغيل التذكير.");
            } catch (Exception ex) { toast("تحققي من عدد الدقائق."); }
        });
        disable.setOnClickListener(v -> {
            getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean("enabled", false).apply();
            ((AlarmManager)getSystemService(ALARM_SERVICE)).cancel(ReminderReceiver.pendingIntent(this));
            statusText.setText("التذكير متوقف.");
            toast("تم إيقاف التذكير.");
        });
        applyTheme(themeSpinner.getSelectedItemPosition());
    }

    LinearLayout.LayoutParams matchWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    void addHeading(LinearLayout root, String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(19); t.setTextColor(fg);
        t.setPadding(0, 24, 0, 6); root.addView(t, matchWrap());
    }
    void applyTheme(int p) {
        if (p == 1) { bg = Color.rgb(25,25,25); fg = Color.WHITE; }
        else if (p == 2) { bg = Color.rgb(232,242,231); fg = Color.rgb(24,70,45); }
        else if (p == 3) { bg = Color.rgb(247,239,220); fg = Color.rgb(65,48,32); }
        else { bg = Color.WHITE; fg = Color.BLACK; }
        getWindow().getDecorView().setBackgroundColor(bg);
        if (verseText != null) { verseText.setTextColor(fg); refText.setTextColor(fg); }
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("theme", p).apply();
    }
    boolean validTime(String s) {
        try { String[] a=s.split(":"); int h=Integer.parseInt(a[0]), m=Integer.parseInt(a[1]); return a.length==2 && h>=0&&h<24&&m>=0&&m<60; }
        catch(Exception e){return false;}
    }
    void loadAyah(int n) {
        ayahNumber = n;
        getSharedPreferences(PREF, MODE_PRIVATE).edit().putInt("ayah", n).apply();
        verseText.setText("جارٍ تحميل الآية...");
        executor.execute(() -> {
            try {
                URL url = new URL("https://api.alquran.cloud/v1/ayah/" + n + "/quran-uthmani");
                HttpURLConnection c = (HttpURLConnection)url.openConnection(); c.setConnectTimeout(12000); c.setReadTimeout(12000);
                BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
                StringBuilder sb = new StringBuilder(); String line; while((line=r.readLine())!=null) sb.append(line);
                c.disconnect();
                JSONObject data = new JSONObject(sb.toString()).getJSONObject("data");
                runOnUiThread(() -> {
                    currentAyah = data;
                    try {
                        verseText.setText(data.getString("text"));
                        JSONObject surah = data.getJSONObject("surah");
                        refText.setText(surah.getString("name") + " — الآية " + data.getInt("numberInSurah") + "  |  " + data.getInt("number") + " من 6236");
                    } catch(Exception ignored) {}
                });
            } catch(Exception e) { runOnUiThread(() -> verseText.setText("تعذر تحميل الآية. تحققي من اتصال الإنترنت ثم حاولي مجدداً.")); }
        });
    }
    void playAyah() {
        if (player != null) { try { player.stop(); player.release(); } catch(Exception ignored) {} player = null; }
        try {
            String url = "https://cdn.islamic.network/quran/audio/64/ar.alafasy/" + ayahNumber + ".mp3";
            player = new MediaPlayer(); player.setDataSource(this, Uri.parse(url));
            player.setOnPreparedListener(MediaPlayer::start);
            player.setOnErrorListener((mp, what, extra) -> { toast("تعذر تشغيل التلاوة. تحققي من الإنترنت."); return true; });
            player.prepareAsync();
        } catch(Exception e) { toast("تعذر تشغيل التلاوة."); }
    }
    void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "آيات القرآن الكريم", NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("تذكيرات بآيات القرآن الكريم");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }
    void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
