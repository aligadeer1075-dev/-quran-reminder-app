package com.example.quranreminder;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context context, Intent intent) {
        if (context.getSharedPreferences("quran_prefs", Context.MODE_PRIVATE).getBoolean("enabled", false)) {
            ReminderReceiver.schedule(context, 5000);
        }
    }
}
